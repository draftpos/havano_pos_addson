### Havano Pos Addson

addson of the havano pos

### Installation

You can install this app using the [bench](https://github.com/frappe/bench) CLI:

```bash
cd $PATH_TO_YOUR_BENCH
bench get-app $URL_OF_THIS_REPO --branch develop
bench install-app havano_pos_addson
```

### Usage

# main link

http://localhost:8000/havano-pos-touch-ui.html

# Dont Worry About so many html files and css there, some of them are not in Use.
