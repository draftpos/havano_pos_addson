# settings doctype

-on touch, randomise colors on items from group [done]
-when user clock ite, go to next line[done]
-pop up value to zero [done]
-when user add quantity from popup it should go to second from last item, reason being, that will be the item with something[done]
-a new row should not be allowed when the previous is empty
-when the header of table row sticky[done]
-Make group items fix in size[done]
-make color or the header table same, with header items[done]
-items cells to take current header color[done]


DO THE SAME ABOVE ON NON-TOUCH