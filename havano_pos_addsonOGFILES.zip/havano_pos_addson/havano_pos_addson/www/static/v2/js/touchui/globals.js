// Global variables
let allItems = [];
let allSettings = [];
let allCustomers = [];
let allPriceLists = [];
let activeItemField = null;
let currentFocusIndex = -1;
let isInSearchMode = false;
let currentSearchTerm = '';
let currentSearchResults = [];
let currentRowForQuantity = null;
let itemGroups = [];
let currentItemGroup = null;