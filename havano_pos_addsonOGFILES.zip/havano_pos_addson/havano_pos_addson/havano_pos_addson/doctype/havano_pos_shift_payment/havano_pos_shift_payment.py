import frappe
from frappe.model.document import Document

class HavanoPOSShiftPayment(Document):
    pass