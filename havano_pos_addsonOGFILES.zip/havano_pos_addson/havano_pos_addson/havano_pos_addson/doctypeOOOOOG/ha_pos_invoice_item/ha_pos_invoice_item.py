import frappe
from frappe.model.document import Document
from frappe import _

class HaPosInvoiceItem(Document):
    pass