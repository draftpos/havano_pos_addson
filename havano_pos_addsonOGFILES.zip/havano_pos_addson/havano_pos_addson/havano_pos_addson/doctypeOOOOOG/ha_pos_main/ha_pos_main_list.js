// frappe.ui.form.on('Ha Pos Main', {
//     refresh: function(frm) {
//         alert("Script is working!");
//     }
// });